# arti-bench

A simple benchmarking utility for Arti.

This works by establishing a simple TCP server, and having Arti connect back to it via
a `chutney` network of Tor nodes, benchmarking the upload and download bandwidth while doing so.

License: MIT OR Apache-2.0
