# `arti hss`

`arti hss` is only supported in builds that have the `onion-service-service`
feature enabled:

```console
$ arti -c hss.toml hss --nickname acutus-cepa onion-name
error: unrecognized subcommand 'hss' (hint: recompile with the onion-service-service feature)
```
