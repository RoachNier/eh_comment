# `arti hsc`

`arti hsc` is only supported in builds that have the `onion-service-client`,
`keymgr`, and `experimental-api` features enabled:

```console
$ arti hsc --help
error: unrecognized subcommand 'hsc' (hint: recompile with the onion-service-client, keymgr, experimental-api features)
```
