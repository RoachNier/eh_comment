//! Runtimes designed for testing.
//!
//! Some simulate failure conditions; some monitor activity.

pub(crate) mod badtcp;
pub(crate) mod count;
