# tor-async-utils

Utilities (low-level) for Tor

Miscellaneous futures-related utilities for `tor-*` and `arti-*`.

This crate lives near the *bottom* of the Tor crate stack.

If you find anything in this crate generally useful, it should probably
move out into a crate of its own.


License: MIT OR Apache-2.0
