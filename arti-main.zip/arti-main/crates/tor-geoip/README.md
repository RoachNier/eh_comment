# tor-geoip

A crate for performing GeoIP lookups using the Tor GeoIP database.
