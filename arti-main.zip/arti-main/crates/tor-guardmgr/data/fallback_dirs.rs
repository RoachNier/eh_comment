/* type=fallback */
/* version=4.0.0 */
/* timestamp=20210412000000 */
/* source=offer-list */
//
// Generated on: Thu, 24 Oct 2024 14:26:19 +0000

vec![
    // Nickname: bauruine
    fallback(
        "FEEBABA2B6FAF53AE1DC8DDA8681CE026537DFA4",
        "wo9NA5RXkPAc7sB2301JBpvdk1RvSOGZEzgwuWP/msA",
        &[
            "185.229.90.81:993",
            "[2001:1680:101:43f::1]:993"
        ],
    ),
    // Nickname: RDPdotSH
    fallback(
        "23EE105C07D5B24FF5515059FC7A7C4C22344BDF",
        "9pQZuJ58rdsGzTWQIcSTt88Kat6y6BqZOgkys2qzug4",
        &[
            "45.138.16.44:110"
        ],
    ),
    // Nickname: RunBSD
    fallback(
        "568E434F725B7828D17EF2B33C2F5CC84F18FCE3",
        "kFvApjUTMdg1IhRPgtC5NVjmaec4nRWvu0Yi1gSHHz8",
        &[
            "91.219.238.148:9001"
        ],
    ),
    // Nickname: McCormickRecipes
    fallback(
        "8370FC4C190D0020FA594D8232DFE34B5B30AF05",
        "kdrS75yScoa8H1vNCo5PJEXtTRfBAKs18MLPKgV1DDs",
        &[
            "38.97.116.242:9001"
        ],
    ),
    // Nickname: stvnrdgme1
    fallback(
        "1C4A33507E401B79263D028D1927F4F54AD83584",
        "fZ9yyjfYzgFOXgy7A91+3TJ1wQWWP2Inf046jncDkEo",
        &[
            "176.123.1.67:15901",
            "[2001:678:6d4:4010::b0]:15901"
        ],
    ),
    // Nickname: Charybdis3
    fallback(
        "8BF4E024210FF5DB1D7A4AFEBE11B48C73BFE779",
        "EnL5izO27pVmJl5RjpTvlUOshZzbAQazQ8DwPkNYbTQ",
        &[
            "92.205.129.7:21",
            "[2a00:1169:119:b120::]:443"
        ],
    ),
    // Nickname: Ebirah
    fallback(
        "ADFAC932FD6BFBE3547D055E20F220512C156D1B",
        "5HoGm6F0Zq2XzdyRmMYhmuybjzmiCGUxnftdXlLWMwA",
        &[
            "193.31.27.59:9001",
            "[2a03:4000:2b:100a:84de:15ff:fee1:df4b]:9001"
        ],
    ),
    // Nickname: bauruine
    fallback(
        "C520B551D503E2694E1F32C8AED3D716FCC22BFA",
        "5A9hSXaFNmfFK1COYxdpPk0hToF8puojga38v+T0VWk",
        &[
            "185.40.4.100:443",
            "[2a0e:4005:1002:ffff:185:40:4:100]:443"
        ],
    ),
    // Nickname: Schwabentor
    fallback(
        "F05114B22E66D08581B5936C646F62649485D879",
        "AW2W1qRXVvKcdRqHKhxNhel/cuiRqhtBmww6k+lD6Do",
        &[
            "85.214.202.158:9001"
        ],
    ),
    // Nickname: Estevez4893
    fallback(
        "7851D819D31A5118C5334758AC4D4A662A3C2CE8",
        "zhENo/MamcpylDWG0INcj97VKm/U/IfkoPjdSy0WqXE",
        &[
            "205.185.124.193:45582",
            "[2605:6400:20:1c01:7d33:a5db:c2b9:1092]:45582"
        ],
    ),
    // Nickname: Servum
    fallback(
        "E31B3E63F132961C70C5FCEE2187F4F935391234",
        "rKbDW+55SglTm/FbNOfKGR9UGubQlAQA1kYUZ2wHllI",
        &[
            "128.0.64.148:8443",
            "[2a0c:d480:c1c1:1286:ffff:ffff:ffff:ffe]:8443"
        ],
    ),
    // Nickname: TheIllusion
    fallback(
        "58B81035FC28AACA8F0E85E46C8EBAD7FCFA8404",
        "m1Y8zNCQlxTaFWXmkXnQ5077BK91YGIzNkIWBgo/CDc",
        &[
            "128.127.180.156:443"
        ],
    ),
    // Nickname: enterthevoid
    fallback(
        "0C8F681ED2E2E4DA5525AA11416E970B7158CACB",
        "YI3o3WsXzuELBc64uU1dG7jSVemN78uT/Ce30iY4u88",
        &[
            "89.147.111.124:9001"
        ],
    ),
    // Nickname: thoughts
    fallback(
        "7E1E7281107AF03B4C2C8744C7F82F2924311316",
        "8jMgV/+2UKsBM2Knd6C457P47eSAXYfD1/eklxAIcpk",
        &[
            "192.211.48.226:443"
        ],
    ),
    // Nickname: technofobe
    fallback(
        "00962D2DD0B9BF3A6AF1D5EB201132388ACA1424",
        "7tF5vwJZNg1f4A/JzhaexPaCT4YL1GgG6hBhFfsNvyA",
        &[
            "5.189.155.39:9001"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "1A243DA6F639A9C99B4391158E0E14E89C29754C",
        "kL7QfCnea+G19cJ+1XOkzxUI9TvkdEygxHoqGSZn5/0",
        &[
            "45.141.215.97:9000",
            "[2a12:a800:2:1:45:141:215:97]:9000"
        ],
    ),
    // Nickname: AndrajNode
    fallback(
        "53F65A431202F921693BCC295EFD96E1A1E03A53",
        "XNGlb3ipObrf4J2kuE7kbnm2y/myfUBqiNjGduvD4po",
        &[
            "213.47.154.149:443"
        ],
    ),
    // Nickname: bauruine
    fallback(
        "9435C7DA2721D446406662238B44913885CD9A67",
        "gS0iFVyshtcXJ1gHIFge+fdQGtre9SHEfIXPlJ9k2bY",
        &[
            "83.77.218.29:30004"
        ],
    ),
    // Nickname: UnredactedCalyx
    fallback(
        "9CD04DC7E27C29AE010B70ABBB78682CFA2ECD1C",
        "zqAZ2X4ayU+a0FAqbdl9+73eXAnhYuYEeDlOuRt0dXY",
        &[
            "23.154.177.17:443"
        ],
    ),
    // Nickname: gesdm
    fallback(
        "BF54EE3193751481579BA7CC7D8E1DF0A01AFB30",
        "V0J269JISxRT5lE3e9ylz3L3M6PRlaRZrq4wMNdmYUc",
        &[
            "18.18.82.18:9001"
        ],
    ),
    // Nickname: salexxx
    fallback(
        "E5293854BEF5F319210CA894B8D365FED578BE7D",
        "TTOYDdJj3zJ32JuLXBc/QgxqnxauiaUd1LBiz7qysQQ",
        &[
            "84.247.164.52:8916"
        ],
    ),
    // Nickname: pjahra
    fallback(
        "B6526852EF18FB54BC91437B54055D16FD581898",
        "Tf+HvdnLC7QKPy11T2SrcWB44B2LzVwmeQYs+xx8p4w",
        &[
            "176.198.159.33:9001"
        ],
    ),
    // Nickname: F3Netze
    fallback(
        "50AA9FEA6A3A609686276C4CF0C2A1AFB2ECCA1B",
        "aAGP0BwnARlsjn7fBAEVbKelha0m3TF0dABu1CLFY10",
        &[
            "185.220.100.241:9100",
            "[2a0b:f4c0:16c:15::1]:9100"
        ],
    ),
    // Nickname: Quintex12
    fallback(
        "40E7D6CE5085E4CDDA31D51A29D1457EB53F12AD",
        "32BuSI9F9uwHv1m4z8IbR2JR0MszfimlYHS9yqqdiqQ",
        &[
            "204.8.96.102:443",
            "[2620:7:6001::102]:80"
        ],
    ),
    // Nickname: TaurNuFuin
    fallback(
        "F42293743B0BC4A33C80A542A451EE6C64B27DE9",
        "dylqDUbEs1xfXyicQ+w/oJ0kcyT9OhCtW1HH7gCyHj4",
        &[
            "188.192.183.75:9001"
        ],
    ),
    // Nickname: aristotle
    fallback(
        "D4F0C88E27A6A50C4601E4E4F409121D07AB764B",
        "ytv68yDpI0k4FSzRZtvp6oSClz6jbpdVInr3snNKNCA",
        &[
            "45.21.116.144:9001"
        ],
    ),
    // Nickname: DFRI41
    fallback(
        "81F4867EC51E06053346C0226FB82AC8D14BE4D2",
        "RQVwVoK3xjoROUgTGMFigC7nt5ioTgNIbCOgKGlAeyk",
        &[
            "171.25.193.235:9050",
            "[2001:67c:289c:2::235]:9050"
        ],
    ),
    // Nickname: Sovereign2
    fallback(
        "0F35F5DDD162199B60B2D2CBC9BB7E35A084AFF6",
        "AUzkvBg10YpspLf4f+n6dc2LZkLFZ9FlYzdQDTUPNjI",
        &[
            "178.170.10.3:9001",
            "[2a00:c70:130:1::506]:9001"
        ],
    ),
    // Nickname: DFRI35
    fallback(
        "FD1B84A26BC18B32D115B1B8A7048D6FC85248EE",
        "iT/nkjDRHveLOJF9pEINzpPdZ72In5mXDKH1M2qJfzs",
        &[
            "171.25.193.20:9050",
            "[2001:67c:289c::20]:9050"
        ],
    ),
    // Nickname: Infiltrator
    fallback(
        "F690E0284D7ABAA22317BC87170C67C36AE950A8",
        "qyQilpYcfxGOa3FA7bFbE58Y5k+yL2a/FKcO9NKABKs",
        &[
            "82.165.206.196:9001"
        ],
    ),
    // Nickname: ParadiseTorRelay7
    fallback(
        "B55DF560D234C531BFE623079CF685B4FAF8EDFE",
        "LlD3JmHIyHNEOATjG6q62V/0D+qYH2yuMYzgMGFzntg",
        &[
            "85.24.237.73:443",
            "[2001:9b1:9bd0::73]:443"
        ],
    ),
    // Nickname: DigiGesTor5e3
    fallback(
        "E006EA04C696BBD6E35407538131305FF3CB8C16",
        "jRsAgAb1fjB4Cx1nRt0LhiXVQf8DD5qAtGskxWSEZKQ",
        &[
            "195.176.3.24:443",
            "[2001:620:20d0::24]:443"
        ],
    ),
    // Nickname: CryingOnion
    fallback(
        "5A9B2EC4C652EC4FF72C8C673937BE27B3486666",
        "xwCJPnbwv2I4QcbpM31lai6cjI5vfJ/seGDQqIJ7Hy8",
        &[
            "5.181.51.52:9001",
            "[2a03:4000:3f:12:9460:76ff:fe49:d419]:9001"
        ],
    ),
    // Nickname: phobos
    fallback(
        "9DC0D6442AE1036FDB556185C95754911EB1065A",
        "HlLYiKrDdULSf/zk8fbFeKwxK3EuepIe5kxdbZRzziM",
        &[
            "94.23.76.52:8080"
        ],
    ),
    // Nickname: schweren
    fallback(
        "4953D65C802860DED172D788B9660BC29DF92235",
        "0QGhVKWxVED2bNPeXqgcxwt89tMeLSdBkBH4MsZ6JnI",
        &[
            "89.58.30.165:9001"
        ],
    ),
    // Nickname: boxoffice201
    fallback(
        "772ACD8767F3D24312416FAF2ADB70E6ABA7CB3D",
        "AEgqmOJgWfUol8vXI2/q5KmNfzhgQ43fae5UcslLvY8",
        &[
            "209.114.126.201:8080"
        ],
    ),
    // Nickname: SupportSeaWatch
    fallback(
        "F85CDCD037B3C834D03F046205047C409557A5BC",
        "gEEdCUlHWbE9UkYLo90MSHPBZPJyf1N3wl3RLaW98iE",
        &[
            "85.214.111.133:443",
            "[2a01:238:4273:fd00:e5ca:9f03:dfca:9a71]:443"
        ],
    ),
    // Nickname: HA71
    fallback(
        "27C1DF5B64406B5606AF630C813BCAD3C920BF73",
        "xvcE1+EFw1iwPUsE4+ncfMQltpkT+dbnqbvUSyqsoO4",
        &[
            "91.132.146.181:9001",
            "[2a03:4000:37:63:4427:b8ff:fe6a:881e]:9001"
        ],
    ),
    // Nickname: CCCStuttgartBer
    fallback(
        "6FBD7EB6B8EA276F59942FDF8BFA044FC0F24492",
        "H9i5pR+h/7co/q8EN/66H6LmPYtR5wiFJ68zjjyIR8c",
        &[
            "185.220.101.81:9100",
            "[2a0b:f4c2:3::81]:9100"
        ],
    ),
    // Nickname: Tor26EM1
    fallback(
        "81C1B8F8DEBAC577AB1BDE4C3EC55175F8AD3882",
        "GVHlwzl706oRnDPz+WcWPdgLqD3mXqKOvAu8tV74Whs",
        &[
            "5.196.4.91:443",
            "[2001:41d0:401:3200::4012]:443"
        ],
    ),
    // Nickname: RDPdotSH
    fallback(
        "B9F4415E4A83FA262C300DA9D8B2BCFFCD5CED8D",
        "6TvFZujQd0o1LsGNT3YozO18clsEBm2Y5LveQoawSBs",
        &[
            "185.241.208.183:443",
            "[2a12:a800:2:1:185:241:208:183]:443"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "7153CBA69270BC55485B3796FB8D9C1AA7A119C7",
        "X+ygQ6xWC9kBjiaFk+oyI10WnI26nhcIYseIEgtfaP4",
        &[
            "2.58.56.43:7430",
            "[2a12:a800:1:1:2:58:56:43]:7430"
        ],
    ),
    // Nickname: FreeExit
    fallback(
        "68A54E180F778AFE96C7906A528B1EFEDFD42A47",
        "RWQyE9bclG2Qr+fFZPq0vfJuFVTEv/gmZ0V3uInpWOA",
        &[
            "179.43.159.195:9001"
        ],
    ),
    // Nickname: Ishotmyshot
    fallback(
        "3CADFF1E426C41699887B48EFEA375A81E888E3C",
        "iXMAZxgBTTGtZ6NAz3KebLjw9C+yJt7UnsDK/A8+KMo",
        &[
            "37.1.204.243:9001"
        ],
    ),
    // Nickname: bauruine
    fallback(
        "153460C0FE0945B0269999554E85534A2F709D8D",
        "SY5Wg9rWAns5TACuvQq15xEKDpIIp3VmNIijNTS5RTw",
        &[
            "50.118.225.161:8444",
            "[2a0f:ca80:1337::9969:dc10]:8444"
        ],
    ),
    // Nickname: arbitraryTessa0
    fallback(
        "A2CD32D9D0668DB764AD68C745CE29693CA851B9",
        "2rpGWVMtACAPtAiDquuU9YKfCy9Ul+1zXjLt7yeDiWI",
        &[
            "95.217.112.245:443",
            "[2a01:4f9:4a:2e4e::2]:443"
        ],
    ),
    // Nickname: marcuse10
    fallback(
        "16E09CB06617A7215885B6C7C8436B1F8D07960F",
        "81Wbl5/TquRK12KYSSuJNGf1b/FFo+BjYaEc44RaUC4",
        &[
            "178.20.55.182:9001",
            "[2a00:1b88:4::4]:9001"
        ],
    ),
    // Nickname: FreeLasagna
    fallback(
        "A99BDA7894C6FBFF88A5DD03175D6B897155595F",
        "3L+lbeALuN4NI8XqudY0q4cAHlhldWt4FpYkuQVmfFI",
        &[
            "37.27.8.223:443",
            "[2a01:4f9:c011:b2fd::1]:443"
        ],
    ),
    // Nickname: Caramelo
    fallback(
        "C6B6F625CF68D3884D5895E0C7A399ECF0C04CA8",
        "wRsxQCpK4NvdWHNgclITK2U6PDAUndGx5SF0XSdYLeg",
        &[
            "109.104.155.20:9006"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "13FBC97516DC854399E70BC7CA9A4513FFD4F08C",
        "Y5YiWtxmv9SXrXstem4m3sfK2NRcf+Ksh5H5sX12upE",
        &[
            "45.80.158.23:110"
        ],
    ),
    // Nickname: DangDongDai
    fallback(
        "49CC8033C445AA0B05AD6C977BBC8DBDF4C519D1",
        "5YYV0urosHqrImDVuQQbR/vy3RAId4MmIOpe7v9aIuI",
        &[
            "93.177.73.98:16843"
        ],
    ),
    // Nickname: relay841267984
    fallback(
        "FFA3B6DC29FCD48D85C8D90CAACE55C4BC4F3462",
        "zr7je3iQSZIRAFrTlv4V3ryNzFlEpgWZWU9G7+azZd0",
        &[
            "146.70.57.18:34675",
            "[2001:470:1f10:38a::2]:34675"
        ],
    ),
    // Nickname: cozybeardev
    fallback(
        "9CD8AC434F90DC1AA7E18D019A34ACEB218E9EA5",
        "djBlQW5+LwX1H8PdkxmR/+L6AVkWXTaVC3NJT7TghKI",
        &[
            "77.221.159.192:443"
        ],
    ),
    // Nickname: Digitalcourage4ipcb
    fallback(
        "85C29D07636BEBACFCA0DF5AB31B333882745065",
        "m91IX4gm3IQzt09ZKkuhM3HXn+6Ozk5oE0HOIJOUBSI",
        &[
            "185.220.101.98:993",
            "[2a0b:f4c2:4::98]:993"
        ],
    ),
    // Nickname: RadicalPrivacy3
    fallback(
        "DDD2070285C0CF9AF0481851B5CAE54C35CCDA42",
        "Q14GbXGs2ub3UAISuRWkA6uU6/wULI/XfZZJ0HwjiB4",
        &[
            "37.46.208.113:443",
            "[2a00:19a0:3:d0:0:252e:d071:1]:443"
        ],
    ),
    // Nickname: Pierrette
    fallback(
        "6F6CE59AC456500E505D82AF09ADFC583022DB87",
        "P0vKxjIWw1Ved/Vt1LSuZ55Av97RSmVsu/PP6kbXc+k",
        &[
            "185.241.208.54:443"
        ],
    ),
    // Nickname: mylocXdus01
    fallback(
        "5DC40F5357EDF4809A9010828172072C95A73514",
        "J1OisW5Gg5COLIeT3folzT0mhoy/OU02N5/kQ/nCbss",
        &[
            "146.0.40.193:9001",
            "[2001:4ba0:cafe:f55:dead:beef:dead:beef]:9001"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "2EB89757F1D8228784335232E2CE2989D220E590",
        "EGtdi0gyfac8oT8xvNvCFuZy1K/DVtg9LssCK9o70VU",
        &[
            "45.141.215.95:8430"
        ],
    ),
    // Nickname: bauruine
    fallback(
        "E6B550BFD6A35725EFADA0DFD07511532FC18AE8",
        "40wkVcJjX+Q/ryehdyqyYPV5mNoyS2KMIxEqm0Wy9Xg",
        &[
            "185.40.4.101:444",
            "[2a0e:4005:1002:ffff:185:40:4:101]:444"
        ],
    ),
    // Nickname: Kanellos
    fallback(
        "9E47303453F961132C2A59D2966F5A6EFA13B6A5",
        "o7MuTt3tSvt/9P4WJLYJou1gbHTk0K490MnC/oZ5BBY",
        &[
            "146.0.36.87:9008"
        ],
    ),
    // Nickname: MaverickPass
    fallback(
        "8AB172C11996EC969EF5B42B7CB8ADDD07455AA4",
        "LOco6Yx3ypOl9KX4X9qAUNThqY5VM64AcCa4Ji6MTMo",
        &[
            "136.243.174.159:9100",
            "[2a01:4f8:171:238c::2]:9100"
        ],
    ),
    // Nickname: Alps2
    fallback(
        "4236EA92D6B758A98C5334051C2D88FCB4843CC5",
        "SAU/0XrEG1hkz/86udlSPoF97kG+0sH6TTLSlPYofkY",
        &[
            "85.215.66.179:443",
            "[2a02:247a:266:b600::1]:443"
        ],
    ),
    // Nickname: KingPommes
    fallback(
        "1F43C824C1561935D22FA45CB87BDF8DD2E70B05",
        "NcWbaV74+zZ+NhWiuhvmEtRBzHivE8bVhHMer5Wv+5s",
        &[
            "85.215.34.3:443",
            "[2a02:247a:243:9100::1]:443"
        ],
    ),
    // Nickname: Quintex97
    fallback(
        "AF57275D067ACF1EADE51E32860C8E569190BB24",
        "+ia7Z3M/oIrI6z6tKEenPMJFJzmNrRVmHBEQHhbTT0s",
        &[
            "204.8.96.186:443",
            "[2620:7:6001::186]:80"
        ],
    ),
    // Nickname: Aramis
    fallback(
        "2B3AAC97B269D59E6D642C8BFB174EDD13741C38",
        "ftqsBFYNYFyYzkNjvGl/ydiYw+2mIovafirfpMfNNGs",
        &[
            "199.195.253.156:9000",
            "[2605:6400:10:1362::2]:9000"
        ],
    ),
    // Nickname: bauruine
    fallback(
        "50637D5AF4B640A54AC7B4AC5C6B9BB0DBC4CD11",
        "pyepgOzXiKIsgokLzTiY67PJZHaEQSbCpoo3QbxCKT4",
        &[
            "45.134.225.36:8443"
        ],
    ),
    // Nickname: DFRI33
    fallback(
        "940E1CDEF915CC88B524D34089C8F9764CA9822E",
        "DpAPCHSQ1PjzokicFfvpIeKmacjrC4l+arvC/w4sqm0",
        &[
            "171.25.193.20:9001",
            "[2001:67c:289c::20]:9001"
        ],
    ),
    // Nickname: CCCStuttgartBer
    fallback(
        "7916A965E564B3C7EDFAEABC880B7ED4A3225CF9",
        "ruKvT/funGCUyolXFTsAjFMPrtNy/Ps9dUhMqlcEUEw",
        &[
            "185.220.101.70:9000",
            "[2a0b:f4c2:3::70]:9000"
        ],
    ),
    // Nickname: haustre1
    fallback(
        "B8F9E02E70A2A32E6EF1C04FC9F9A7B87435E50A",
        "Npq/5FJbH7DAkue+KlxnunazWNcH8xHfYav21BzS0bs",
        &[
            "82.197.160.67:9001"
        ],
    ),
    // Nickname: vidaloca
    fallback(
        "A8D34CA04DDEFAB78F6D5341B1DE00C5D4D7D91C",
        "b58l4w9OcGSWwnkpzyU3UDweVxIvmsV1jIP63JaiCqY",
        &[
            "162.251.117.10:443"
        ],
    ),
    // Nickname: bepira
    fallback(
        "A1617C69B4356D8DDBCEC630CE61AD22DEB71DCB",
        "W/EMXRIjpoUsbcQuRwUoZ5y0aLIhrvzBWSU5D5pV8O8",
        &[
            "93.99.104.128:9001"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "437A08EB0D74867513BEBCE84C55BC1DA94D32CF",
        "fT1nMdkYQ6xSgH/ZPa8TZSg/SrBSHOjj5WgxzKxu1Kc",
        &[
            "45.138.16.240:9100"
        ],
    ),
    // Nickname: FrostShark
    fallback(
        "23BAB4A9B1B7F553599CD81AED553FACB7B35210",
        "cpqJBuuDju7s2R8Z+iJrjHkEFQviOzXmW0h252gOTXc",
        &[
            "91.193.18.143:9001"
        ],
    ),
    // Nickname: NTH38R1
    fallback(
        "E347622E1228CB1490817B9E78DE2107CC17E1B4",
        "2U7E2bGSgL4UGfbtKH99FlLFj9CIPI/TzX0W/nzh+7M",
        &[
            "192.42.116.201:9000",
            "[2001:67c:6ec:203:192:42:116:201]:9000"
        ],
    ),
    // Nickname: systemli01
    fallback(
        "ACEA5C60E4D37D9770246E81C19DB1C3F3CD1A8F",
        "j+afFvNZmTX9DsciCfhVHW/mtLNQCwgSbMESdKTB6E4",
        &[
            "192.68.11.203:443",
            "[2001:678:a40:7001:2::4711]:443"
        ],
    ),
    // Nickname: twoandtwotwo
    fallback(
        "A2211BEC0CEB70C2634F425200C82B89DFFB9923",
        "AQWObGQnmL3GdnKypV2S8qNBQZD1adCuy5rUeFQ/oxI",
        &[
            "135.148.52.241:443"
        ],
    ),
    // Nickname: dc6jgk6b
    fallback(
        "0BE2C6C8FDCB96AF65803D3CEE49214D619FC542",
        "4hZG/w703L7uNfxdakdqaIUOIS2LpOqeAcGMglJv9iU",
        &[
            "62.141.48.175:444",
            "[2001:1b60:2:32:4104:104:0:1]:444"
        ],
    ),
    // Nickname: chickenshit
    fallback(
        "A38625F86DD9F8DFA2C6CA4D7CB47DB801FBD7E0",
        "jBT/nEX8Z0cBxiaXZ3oG+ixWcNusN2pcUijv4EBb3V0",
        &[
            "23.92.34.120:443"
        ],
    ),
    // Nickname: marylou1
    fallback(
        "578E007E5E4535FBFEF7758D8587B07B4C8C5D06",
        "qm5XHTSZpVLD/fHmAUyUuAgzQszQFaFqLcIZXzExctM",
        &[
            "89.234.157.254:443",
            "[2001:67c:2608::1]:443"
        ],
    ),
    // Nickname: pinkiepiie
    fallback(
        "CB9C2CAC297220FC6778035F9F14726D02D11250",
        "2ZjYd/YVymO4X872x40X3tPkZ4+0vOk2ugfLg+eKBnw",
        &[
            "179.43.182.252:9002"
        ],
    ),
    // Nickname: NgePTimE
    fallback(
        "DB451037C23AF3D028AE1B7E2F82BE5CA77B98A5",
        "0Zv1Uw2dsyP2Se2mO1ljqUhata+/MusH2dwnoz2EHFM",
        &[
            "107.189.8.181:443",
            "[2605:6400:30:f49b:e2ee:34f8:c854:6f63]:443"
        ],
    ),
    // Nickname: comedy
    fallback(
        "0CF2F07FF0581EBBCCDF209E655694358A98D816",
        "cRUYf5+adIviX5yyOlTSY9T1Z5ZuHy/t55tmVFAn1lI",
        &[
            "185.225.17.105:9002"
        ],
    ),
    // Nickname: Kroell
    fallback(
        "44DF1007B545B4D8057F279025EBB33CF99BE227",
        "njevDDB+9dBrDn8+7iHZTxQWpXBgbfqnzjevFTAqyfk",
        &[
            "80.241.214.102:443",
            "[2a02:c205:3001:7714::3]:443"
        ],
    ),
    // Nickname: Unnamed
    fallback(
        "38316AF9D28F99A451C8789BE21C363ADD0F6846",
        "P8ZLYjZ6nKAXPyyT0rUz0PoqCF7831F3vgjq7qHAr6o",
        &[
            "94.23.149.136:9100"
        ],
    ),
    // Nickname: alnutt
    fallback(
        "72C480E844BE33AAD027C5DB0D9CEE2AF67C574B",
        "kGg9sImJJnbjv1vt4lUmrVO3JlMNWe0jwyPOyV1inCo",
        &[
            "95.153.31.26:443"
        ],
    ),
    // Nickname: INSRelay28at5443
    fallback(
        "0DBA891A70AE95D4AD77593A936E6C04ABF2E7CE",
        "QqKUldqnvVD7pCWhgtppmpATsFM4yS+INdSFUuX8I1Y",
        &[
            "140.78.100.28:5443"
        ],
    ),
    // Nickname: PitivierGlisse
    fallback(
        "24494F0C553D13D1F46BE783DDE1572D7F0850BA",
        "zhQr9ipXTEEk8pf3fEJoaB/be/JESq5EsSFPLUqseiM",
        &[
            "141.145.201.126:9001"
        ],
    ),
    // Nickname: 4723
    fallback(
        "3597A3F60A4AFE44A3DDE8B5219F9F85D9B441A2",
        "80du97GDChdz+rIiulHdMMBGPJ2/ic/d45hw1xfONNE",
        &[
            "185.40.4.132:9004",
            "[2a0e:4005:1002:ffff:185:40:4:132]:9004"
        ],
    ),
    // Nickname: RiggsOceanlock
    fallback(
        "07F0E652E4CCB0A0F1E88D0046ECB322E6318C86",
        "gSK85hClpNQ3BRVPTT86dDUXD2sRV76I83xZRKIeSQU",
        &[
            "78.138.98.42:9001"
        ],
    ),
    // Nickname: Chrysophylax
    fallback(
        "1FFDC7F90DBCDE587C3524FB3FBB50B818565357",
        "Fi5lVRKrxJByQ15nV1xr2nd2Q4cPIweuV+pR3ES4Wz8",
        &[
            "24.61.34.233:9001"
        ],
    ),
    // Nickname: torexitams02
    fallback(
        "9928E342EF92F2411D8D68ADC18F6D2B5367171D",
        "/GIMRKUa1ZF2HuRoKMrkOekDmy3orZLqCFJG9sc39cg",
        &[
            "45.66.35.22:1984"
        ],
    ),
    // Nickname: CanisLupus
    fallback(
        "EAC35E29082DE3D3B7641252E98C3B05C8005F2C",
        "VJZgRrMWyOqqmPp/LVDPN1fu/cKa1XN5fWcSeTy1QJI",
        &[
            "135.148.100.92:443"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "43EF5141A4417D0BF1B0AB2AD2C3D74C22355D0A",
        "tGQIgj85UmKAFJVRSiYVuEj5XVgwHQc1yVzBDJlnJEo",
        &[
            "107.189.1.9:9100",
            "[2605:6400:30:f920:f523:28ef:3617:8b86]:9100"
        ],
    ),
    // Nickname: AggressiveGremlin
    fallback(
        "7E33C702C95FB4A3D2C203DB4A40D330C5029D81",
        "+z8miS9WTGqE6Ecs/olCvA6mXkOqzlIzlM4XPaGgfro",
        &[
            "104.254.130.186:8443"
        ],
    ),
    // Nickname: Belgarath4TOR5bws
    fallback(
        "D2F210BE625A7A68010C280A7D3D94E65FAA21BD",
        "X53Oc7Zc0ECOq9R3ZfBp+cVthH8LvbC7QNVa/nrXfBQ",
        &[
            "78.73.42.79:62431"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "2EFC2B8BC724CF435C14066087936BE7CA3C57A3",
        "jQmg5XckgPhw/+sYQSK7kGcW3deYGAlwBhse45fwUlI",
        &[
            "45.138.16.230:9100"
        ],
    ),
    // Nickname: WhatIsThis
    fallback(
        "82431709D1C0284A93FF09B090FE00E627A2F8BB",
        "OGvdEEy9vnRlcFhqAZIkKFC8GXHm65uSoGXrnX5BnHI",
        &[
            "51.222.136.218:9001",
            "[2607:5300:205:200::3dde]:9001"
        ],
    ),
    // Nickname: leckerzwiebelkuchen
    fallback(
        "D349E0A7C940A16FACEEE8BB932CB732ED4619C7",
        "YZq3AEj275mPAPOorO/MNuJ1RiY/j1nfvdkUgkCEdvA",
        &[
            "46.38.237.49:9001"
        ],
    ),
    // Nickname: mumzie
    fallback(
        "037B6C60DAD4DF32FDA29BF458D5C8C816AA8F3E",
        "wy8MgXzblrJNRY7sCsRlQ0nf7QACwS00ozIDSEjZTSg",
        &[
            "91.205.230.113:443"
        ],
    ),
    // Nickname: prsv
    fallback(
        "1B0433881C18CD09A27A904F96938A0E619FE620",
        "VLo7R0c5BLCJWdsF8M5Zzh/x8i4Un9wMBmwQDqUoLgk",
        &[
            "103.252.90.236:9100"
        ],
    ),
    // Nickname: flowjob07
    fallback(
        "F688439202513F2A52797D3CAB740FC43A8ADFAE",
        "fxHWxpJBn3mu1fd7stLIfRmPOTPn7IV03zRkHElgtws",
        &[
            "46.232.248.143:9001",
            "[2a03:4000:2b:77:d412:aff:fecc:a4fd]:9001"
        ],
    ),
    // Nickname: stroll
    fallback(
        "526CC86A8ABD3EF3A60638FFC62C910EA5A562E7",
        "jTY2iXx2UOOIo/LkidLeRc8XP/7FtfGy1sWW6taMXP4",
        &[
            "37.120.144.222:9001"
        ],
    ),
    // Nickname: hui
    fallback(
        "3CA690533F7AED4CCC988942E0FC49C747A49EC2",
        "77ycFY9Ir6Ws2RPKGwzqJDeveVhwo6T6CMTY3RMG63s",
        &[
            "185.164.138.211:9005"
        ],
    ),
    // Nickname: knuckledragger
    fallback(
        "0CB83F633CFB20692E8A615C7B8E524835E2746E",
        "m8CkewFmgBVwvU78BaJGEB0ma8mYrQC2jGel/SeNH9U",
        &[
            "107.189.3.11:443"
        ],
    ),
    // Nickname: baloonasTORrelay
    fallback(
        "10D219897E4F2594AF1EC01C414C2E3754ABA5C8",
        "nE4Kvr8sipw3BB7k+lWRbgieLjFzZ7dUd3MbapE8e3w",
        &[
            "94.16.104.159:9001",
            "[2a03:4000:50:e4c::]:9001"
        ],
    ),
    // Nickname: 929oi1u23jd987j
    fallback(
        "03BE73E581F99EFFF19AB582EF0C7E8E6531CEDA",
        "7PuaaHY7sx08tpAQ52v0Fc1KtWfGxGFLnYzp4W0adFc",
        &[
            "85.215.91.150:9001"
        ],
    ),
    // Nickname: Audrey
    fallback(
        "54713A1E54A819E3C6CC0EBCAF725F285640F252",
        "JkP4nl5gqv9QKA9wyA7uR80FI/4W2aQbxTxV/fPiif0",
        &[
            "142.44.129.21:9001"
        ],
    ),
    // Nickname: NothingToStandFor
    fallback(
        "99C70A9E02D546185106BFC432132503CC3797FC",
        "R6wsD6YsX9x3tiREvC6DmVdcS7I0llMnFzPEQfxI3Fw",
        &[
            "91.229.132.69:443",
            "[2401:b60:5:f855:410c:d769:49dc:967e]:443"
        ],
    ),
    // Nickname: goldsworthy
    fallback(
        "65A90AB81C44DD7D9B73B5529B1151798534AF74",
        "Ay/SUiwCXnNhyicFhbYOXOjb/EI4iS/Xr0FRLmlUWK4",
        &[
            "160.119.253.103:443"
        ],
    ),
    // Nickname: nasrag01
    fallback(
        "66C7803C5F95CEC0D78004E15A0E4399CD0E4787",
        "xKjWPSOhXPC5ztftb8JKONnw/Q50BARpcuoSzACyq6U",
        &[
            "72.211.49.235:443"
        ],
    ),
    // Nickname: bulkypirate5
    fallback(
        "14BE32AAACB9E7F0BCAFADC15986D787B1325BB6",
        "ygGIK3a+vuPgD0lim76eSHNNfgVesNO0B3St0cz1NwM",
        &[
            "45.80.210.20:9001"
        ],
    ),
    // Nickname: Unnamed
    fallback(
        "20F667F680EED64E5E7FC39563241736B3FD9F11",
        "/KxJ0gRQp96RjnQ2NdQ8C17Ak8i80TomqLP3X6n900s",
        &[
            "84.32.131.125:443"
        ],
    ),
    // Nickname: Unnamed
    fallback(
        "0438B5679D52CD10756924D425FDE03B40840304",
        "e8Qi5w7UC1hw8/1r6QusfRfTit4c2P6uaIpUleDpNOg",
        &[
            "72.107.16.200:9001"
        ],
    ),
    // Nickname: Quiv
    fallback(
        "669102E6FA8E116AC05FE823B0634B44499944E3",
        "8ZgqN2AVHN8M+4gVHUo0OBohOkWSAepvrnrAWZW4Azk",
        &[
            "94.100.6.30:9001"
        ],
    ),
    // Nickname: vlado
    fallback(
        "A066E7983758C7CC0097E16ACF4F7B71BAFA44E9",
        "mMYdVpvdUR/z9BZostuHwYBWDOEK8KtSSxnmBX+GS2A",
        &[
            "104.244.76.24:443"
        ],
    ),
    // Nickname: s0yb3an
    fallback(
        "C4C462506D54EDC8EFC8E88E32F4AE014755035A",
        "j6kWYLWJGgAiGfhkmDCJKw2ZOt2JfRpiWyvrtGHMkB0",
        &[
            "87.171.73.58:10222"
        ],
    ),
    // Nickname: INSRelay16at8443
    fallback(
        "B9208EAD1E688E9EE43A05159ACD4638EB4DFD8A",
        "LTbH9g0Ol5jVSUy6GVgRyOSeYVTctU/xyAEwYqh385o",
        &[
            "140.78.100.16:8443"
        ],
    ),
    // Nickname: SweetsAndChocolate
    fallback(
        "9AB85315A496BB7A42BC4F540FA667F7B8B7E801",
        "+CCzyvHhkgmgcBDUGBYMfy3iVj/yhAiZOy/TQsI8PIk",
        &[
            "185.143.102.59:443",
            "[2001:1600:13:101::c5]:443"
        ],
    ),
    // Nickname: motauri
    fallback(
        "01181B31BE5860C7D66DA88F88AD522C06470FD9",
        "MNHo/5XTbtPEtoXq8DFKRNMCs+nfd8SdwQTcfxby5h4",
        &[
            "95.143.193.125:443"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "7B9608D3B65C10061C8546839DD878ADAD91A83D",
        "436XWcXVEzrLMerim7gW0d1F9zQxg+wK23QOlwy3TK0",
        &[
            "45.141.215.167:8100"
        ],
    ),
    // Nickname: NTH44R1
    fallback(
        "9ECF8F065C79FC213A1BF6C1AA2D8CBCC9368F92",
        "yja7ou9UcTJ3nWVE4bXf3QaEPLSoaLNoOXRvgPn2jDA",
        &[
            "192.42.116.218:9000",
            "[2001:67c:6ec:203:192:42:116:218]:9000"
        ],
    ),
    // Nickname: Quintex79
    fallback(
        "F664E5E50B4D216E5940DA7E9CF653F5F9DC561B",
        "i0HVaL9WLLUUl4+tRCMXfwe+yq0meiVwKRsW4c+ufms",
        &[
            "204.8.96.168:443",
            "[2620:7:6001::168]:80"
        ],
    ),
    // Nickname: Elenagb1
    fallback(
        "4B8F0F8BB18F1D9ADC1FE7E54B3D3D605C1919A7",
        "+DXkdFGgjG272Az0waGXH2R58kgm7whnfvzRYk1ixHM",
        &[
            "185.233.100.23:443",
            "[2a0c:e300::23]:443"
        ],
    ),
    // Nickname: torrocks
    fallback(
        "A4F11D693FAB6E949B2B7C18153C3F7989896007",
        "RxH/tHJ2f6SFA3Tf49s1qL9W98Bj9EddS+9oxKSyMu4",
        &[
            "194.55.13.49:993"
        ],
    ),
    // Nickname: jJbzwynG
    fallback(
        "5FF02D4113F0A6888D0A2EE6C57C61A158B7550C",
        "SXe8+P2DNBw9DGyX/Tyjv3YcQEMLURdezeD/WoOMyQ0",
        &[
            "37.187.96.84:80",
            "[2001:41d0:a:2054::1]:80"
        ],
    ),
    // Nickname: elektrobier3
    fallback(
        "40A60D1F1E8AFBED22FCB30B3FBE2E275A14CF99",
        "S30VITBTjpSKoTpY5ndHFz7elhxVt/+KkCMeGlE8rUU",
        &[
            "46.165.221.207:9001"
        ],
    ),
    // Nickname: Krombianschniedschn
    fallback(
        "F2E60DE0F39BEA826B50EB619A014ADCE9619359",
        "89KVbtnbUEA3W8DOYnfyXKemMkTmaACHknmyDOEqrAs",
        &[
            "162.55.48.243:443",
            "[2a01:4f8:1c1c:425a::1]:443"
        ],
    ),
    // Nickname: Ouinouin
    fallback(
        "7E3A4A7AB82002CC6CA69FC21D46B88FA39DFE4E",
        "yv4lD3m9ecWUHSJicRKAuApmlZjIQiFo6ZIP5eHd/co",
        &[
            "54.38.184.55:443"
        ],
    ),
    // Nickname: h0mer
    fallback(
        "33F221E3A9306FA08A857FE266EBE23720EB6026",
        "0oy7ghD8DJM0T0sP6AGobBKh8XTu0qxFaO+X4Z0CmbM",
        &[
            "178.17.170.168:443",
            "[2a00:1dc0:caff:20::eda9]:443"
        ],
    ),
    // Nickname: toreczkowo4
    fallback(
        "54A29E2BBE66F472813D9A937A103F37966205C7",
        "n04ysXwb14WYoNuALrxAeUw/HV6xW//sB79qUciPRB8",
        &[
            "92.204.41.234:9998"
        ],
    ),
    // Nickname: AOP
    fallback(
        "7460C77412E8C8E65ABE1797C652161FE903EBFB",
        "vKHcQUD0/fzFi7Ly4zuCH9m8IZI0c0SbJizJwd4OkO4",
        &[
            "147.135.31.134:443"
        ],
    ),
    // Nickname: gibson44
    fallback(
        "8E3700E561E8E080564648601093AC9570080D8D",
        "g5w+E8179OpZhY4u3/9FZ9Io4By3//rMTn36xhDCU0w",
        &[
            "178.33.36.64:9090"
        ],
    ),
    // Nickname: DebbieDoesTor2023
    fallback(
        "B00A2DE75DEB8ABB3058290CE311A3D9D096797A",
        "+7vzvPr370jZ41d2XuAyztFgrG15rMdbcRJlNAJQDIk",
        &[
            "198.23.133.146:9001"
        ],
    ),
    // Nickname: Teuntje
    fallback(
        "5C124A27FFD658CB76165718DABFFD4093F5C827",
        "av3r4VeJGaLjsP/L8g2Lh8fk/DycYQ1Nrx83Zy3gHpc",
        &[
            "192.42.113.101:9002",
            "[2001:610:510:113:192:42:113:101]:9002"
        ],
    ),
    // Nickname: prsv
    fallback(
        "2576606E3DAA45A8F92DEF93C66499BEFD8C43CB",
        "E91xn0jQtYWAGzuLDgla9CG9N61e8Bg+P58vzSPosgo",
        &[
            "45.148.10.169:9400"
        ],
    ),
    // Nickname: RDPdotSH
    fallback(
        "C050AF296F2D24D7300B5662D0FBE2B27291EE11",
        "HFYnFTlTizPLe1GoU9A6pcWChDe9KgkOygD8LQxxdj8",
        &[
            "45.94.31.26:110"
        ],
    ),
    // Nickname: Unnamed
    fallback(
        "37E5A9C7A7CC4C4ADC2A5F9A00FF031D15AFA4C4",
        "5xG0NIDDjWEXZjufEghL/j1A6VXXQpzjf5LxrwleeSc",
        &[
            "160.16.122.68:443"
        ],
    ),
    // Nickname: iDKHOW
    fallback(
        "AEF1307D097A6B50DB5364FFCEC3568B493CBDA8",
        "BDZG1c9TlUIezrpMAa6erTqNvpnWG75NqJ7DWmyrghw",
        &[
            "38.175.192.191:443",
            "[2606:a8c0:3::4d9]:443"
        ],
    ),
    // Nickname: amaze
    fallback(
        "78F6CC48735658F9F7C2A9FD587BB726EFCD08B1",
        "kmC9xJLNeu66xG1q7l9op6FaiAeTtpubkmeVtcehItk",
        &[
            "135.148.53.55:443"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "B1D9038B9D4E56D1AC5CFE2D3B5FE4A2EA006BC6",
        "MDvTh49YT2YL1tG7vzorqa3YiofBNcFAIb9b/n79cMU",
        &[
            "193.26.115.43:8430"
        ],
    ),
    // Nickname: QuintexAirVPN29
    fallback(
        "A0DB820FEC87C0405F7BF05DEE5E4ADED2BB9904",
        "JkTeNmDJiPMHExIZUUIi4KGrxfzitJE5CSSyElDjd/Q",
        &[
            "204.8.96.82:443",
            "[2620:7:6001::ffff:c759:e652]:80"
        ],
    ),
    // Nickname: Kornnatter
    fallback(
        "9990BD426A0142F0A963E25AB8B7F40A9E81786E",
        "WtKu8woQFNx22BHfH56Pe+nItKeFygQtaBeutBKHIdg",
        &[
            "5.255.111.64:9001",
            "[2a04:52c0:116:e0e3::1]:9001"
        ],
    ),
    // Nickname: LeLis
    fallback(
        "F485E06EE00880E89C21D10086AABF07776591CD",
        "cLy4DmqyCq1RLx7vlpMrb4o+q5cxmQnrjc3LqOmqWcw",
        &[
            "108.181.124.143:443"
        ],
    ),
    // Nickname: tesseract02
    fallback(
        "2A82DFF7BEB7B4269D4D6EAE39DEC36F98214268",
        "7SsQKBtfoS6xBvqJYHzmUHDiLQMXIboHWEnoj8qRwPs",
        &[
            "84.238.10.142:29001"
        ],
    ),
    // Nickname: charon
    fallback(
        "C86C538EF0A24E010342F30DBCACC2A7EB7CA833",
        "TNB2dlWhGFQtkfsXwaZWsHN+gZQR4U8qlNYJr2/L9zw",
        &[
            "173.249.8.113:443",
            "[2a02:c207:3004:1074::1]:443"
        ],
    ),
    // Nickname: yvrTorpi38
    fallback(
        "C7E75243560360CFB1E5ED18E9DF3B88FE68EB67",
        "HgWJr6f0LQkFe1J/kds6bw/ZvWG1l7bKZF9z8XY225o",
        &[
            "23.16.246.111:9001"
        ],
    ),
    // Nickname: vpskilobugnet
    fallback(
        "8A83091651473567F3C95973A3D95E5918D7BEE0",
        "H9Z7ZSaJjpclxzX0sbCQ3cd0grRiRoF+3oOByvW0L64",
        &[
            "163.5.143.76:443"
        ],
    ),
    // Nickname: NTH15R1
    fallback(
        "C51579E3A6611562DDF28FC67CCD16EE5E05717F",
        "WSiqOaSWfYqVlqMIsTj0BbCseySwTkwsDW1cQbrkz8M",
        &[
            "192.42.116.212:9000",
            "[2001:67c:6ec:203:192:42:116:212]:9000"
        ],
    ),
    // Nickname: Unnamed
    fallback(
        "21B55072C00F4522857655FBB0F3E25D75A5357B",
        "86Ov44io/8JNZWILQ7keUeKIZrWP7Ywly3gNZ/oGx70",
        &[
            "109.107.35.154:443",
            "[2a02:1348:179:9145:24:19ff:fee6:4516]:443"
        ],
    ),
    // Nickname: Zensursula
    fallback(
        "B387B87B885B107ADCD749078F1BB81EB7BC7206",
        "c+BC0DxLkh5ymlBUzIK9JnWDyFY+kyVxOT2NuTw30D0",
        &[
            "212.227.150.117:444",
            "[2a02:247a:264:c00::1]:444"
        ],
    ),
    // Nickname: ieditedtheconfig
    fallback(
        "E094CE3392E59129B44B01DB5C63AA52F5FF4566",
        "6DPKQ9RTYBrs+K8Uimus5RB+rgx0sHQgILFFRXhlDCc",
        &[
            "116.202.150.27:9001",
            "[2a01:4f8:241:4d16::2]:9001"
        ],
    ),
    // Nickname: TsakoSeTsakosa
    fallback(
        "EDDBD0CAF28315E85596B1DDF71E76B3605C9898",
        "NGJp10L4IDtD6zFJU94t2XWE2gJ3ffHnnk26X6HcR28",
        &[
            "79.130.19.119:9001"
        ],
    ),
    // Nickname: wix
    fallback(
        "90C9567666C9E4B1C0CB7E50968AC2752AA6D088",
        "pxingDLKqqX0+6AIU3+ym75vHO2zSLNUIk60VLZ3DJk",
        &[
            "185.107.57.66:443"
        ],
    ),
    // Nickname: Olivine
    fallback(
        "EA3F1129F6A22B165674A4FCA8710ED22C9B80EE",
        "TWqK5mLYzUng8f5C5YAvhE1JyavwGHFewpC0P4/RBR0",
        &[
            "130.0.32.111:9001"
        ],
    ),
    // Nickname: Enkidu
    fallback(
        "ED7D6A3CEC3C40ACADBA91882CD04FF76E1C0F4C",
        "GYmHK/KIQtQaNUU+eiXrwwyuElUVRDSHIb2K6RRnGIc",
        &[
            "65.109.67.140:443",
            "[2a01:4f9:5a:442b::6]:443"
        ],
    ),
    // Nickname: Alastor
    fallback(
        "2EB3C230180694A1E848001E20F36F76A2287039",
        "r0Iw5c4GlYu/um4mwPaKFDVWSO1yQyM/daff7yzKgAY",
        &[
            "62.210.123.24:443",
            "[2001:bc8:30c6:100::dead]:443"
        ],
    ),
    // Nickname: CryptoCactus
    fallback(
        "F31A8ECBF669CC4E6B1C14866EBD25C13A70F296",
        "JDsiHzg5LKrmnAea4IBFYds/l6yo/Gig7FrPNV7jXL0",
        &[
            "185.232.68.247:443",
            "[2a03:4000:4e:f3:689c:c6ff:fe24:89b4]:443"
        ],
    ),
    // Nickname: Thorgal314
    fallback(
        "243380AD3D2924A62B137FE0FB64E8017D04236F",
        "Ry4OgvQi1cgllIDbPlG9e/BPEkx93ClqrguYrcxJEMI",
        &[
            "167.114.36.23:8458",
            "[2607:5300:201:3100::465b]:8458"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "7C6686190CE6E8A0A1A5B5B845BF3F14D252D0DF",
        "Oux/Bd/20KC6eAMxSScp6LEB4a5Sku2WvKCyRzEuHYA",
        &[
            "89.58.41.156:110",
            "[2a03:4000:66:15:18a0:6bff:fe90:3147]:110"
        ],
    ),
    // Nickname: champchamp
    fallback(
        "9EE1970E1AD558CF0F297537E32A449EB740CB9D",
        "D2cgQ6/kHySggIeLS0lzTgH5HMzt1QL/uqqTWxetbmI",
        &[
            "172.104.243.155:8443"
        ],
    ),
    // Nickname: Quintex45
    fallback(
        "764BF8A03868F84C8F323C1A676AA254B80DC3BF",
        "BXrbR0utUHjQyG6LI9uyBj9VCYKAtHMwmCQIQ5mFrvY",
        &[
            "204.8.96.68:443",
            "[2620:7:6001::ffff:c759:e644]:80"
        ],
    ),
    // Nickname: Gabrielle
    fallback(
        "3B5B6351330FA96EF3527A1BBB3F389C2310E8E6",
        "3r0HQ1PbmkcjVjCSsPpSIXlaOVPS67IzQUmTF7QZFxU",
        &[
            "176.97.114.202:443"
        ],
    ),
    // Nickname: ForPrivacyNET
    fallback(
        "ADF0D51946DA3294C1F242B0ACADC91FF5F058EF",
        "feA+pdr+lrU1pcJCcKqPqUMGF2ZMPtLjhAhjlOV/KZQ",
        &[
            "185.220.101.206:8443",
            "[2a0b:f4c2:2:1::206]:8443"
        ],
    ),
    // Nickname: frozone
    fallback(
        "C45FE5C41ACC37E4EA4687FFC54A74F124739DAF",
        "nWNSEZDTOaqCkT4OWLc12KjWkbiQ0R5Dy1rF84kZKHA",
        &[
            "144.76.166.141:9002",
            "[2a01:4f8:200:428c::2]:9002"
        ],
    ),
    // Nickname: mayforth
    fallback(
        "C8B0C7701874F0B5AFCDAB0BAE231FE303C8228D",
        "Wb/BZjEFtEcDoKAAySZ0Xsv7T8Sz47DS4V0WnNAo+9g",
        &[
            "43.252.37.14:443"
        ],
    ),
    // Nickname: DarmokAndJalad1684
    fallback(
        "9FFA1EE7FE653F9DA073925BDE299A74DCAC7595",
        "+76ZcXG4euB0pv9nSvFpK29m7p5MNwXqPAOuRHGqLG8",
        &[
            "107.189.14.43:26453",
            "[2605:6400:30:f8da:2b2:a293:30ad:506d]:26453"
        ],
    ),
    // Nickname: ForPrivacyNET
    fallback(
        "7C1A1517C27A0C68329D84D94372E0ACA9390B00",
        "fXGaFM8fBbYxCmATY76lWUHPjqvy6ziyWXpGm1YPNMM",
        &[
            "185.220.101.200:443",
            "[2a0b:f4c2:2:1::200]:443"
        ],
    ),
    // Nickname: Aramis
    fallback(
        "673ABF8132785E24CE48606AD783FDE9BAA92964",
        "tu9cTKn4EIXSQ5/oA1Mz/OkCOXMhrHvPPMet7pmPfHo",
        &[
            "185.241.208.202:9600"
        ],
    ),
    // Nickname: TORKeFFORG11
    fallback(
        "327DF526A04129C8AA55B5F3551BC46AC4BC7A6D",
        "769bxcVIN5iIFI6VH0QYu/m+LIPk2zFkgktGdUbwoAk",
        &[
            "193.189.100.204:443",
            "[2a0f:df00:0:255::204]:443"
        ],
    ),
    // Nickname: misters
    fallback(
        "66783EB4A8C785D6DC771D40F0BA46AFC49F92DA",
        "MAV0cbYTYOu3EERV5CZuUoQk5H3rFEqEJwy+0z8ZDX0",
        &[
            "46.165.220.229:443"
        ],
    ),
    // Nickname: syndicateguys
    fallback(
        "E6A006CA9743820D4FEA212C56F162920612A142",
        "aCAFGWkYbY9i47HapoI31w78R8D86lDy/utGaZvjwgQ",
        &[
            "89.147.110.118:9001"
        ],
    ),
    // Nickname: NTH100R7
    fallback(
        "BBAB820AF8216277F36EAA1787B44BA0A5D7C204",
        "MdvnARimHEPUJsuOfVsScydJgHhfVHOqySa8W4Nq+Dw",
        &[
            "94.142.241.41:8080"
        ],
    ),
    // Nickname: HelloWorld3
    fallback(
        "90F2DC6DC2BC7CA5F5090A5DFC02ACB6D9D561BB",
        "t1Pk6I16g4XmmfR5VRO+wR/sfioN3A98hIwfHOoLK2w",
        &[
            "66.42.99.190:443"
        ],
    ),
    // Nickname: meltdown262
    fallback(
        "0639EEB479EEE652C14842E3C00071D44446132C",
        "DRYF3g+40Fbc2hNoej/Ku7rUYzkGRfjy8Myr+apV428",
        &[
            "84.67.123.134:9001"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "659B0645A1C264D9D8FF4C9DD2B08ADAC392D475",
        "D3aSG801Oca2HVP4ClxG865Ud3/nSjt4S+BknU2Sf8Y",
        &[
            "45.141.215.110:143"
        ],
    ),
    // Nickname: Unnamed
    fallback(
        "7DA6578717E7857E1F73F8763A0647FCE45F7A1A",
        "fOqShkMOWqEC3eBR97rMnAezLVPIIolog64+tgy3p9g",
        &[
            "82.64.135.138:50400"
        ],
    ),
    // Nickname: RunningOnFumes4
    fallback(
        "2B34099ED2BC598C4745C96C873FD73A445646BD",
        "bZyjpl8bqjYfnTiXvMV+RVoUUAJDYKu7Gr+3pMdf9rk",
        &[
            "185.82.219.109:443"
        ],
    ),
    // Nickname: Quintex42
    fallback(
        "FE00A3A835680E67FBBC895A724E2657BB253E97",
        "fJ+yyITknueUUlv6GZo4zgrK6FMgvgZAaV3+3cgbZlM",
        &[
            "204.8.96.65:443",
            "[2620:7:6001::ffff:c759:e641]:80"
        ],
    ),
    // Nickname: cozybeardev
    fallback(
        "C7A51E46740C15DEC0535AF5560A1919CE6E5758",
        "ILkr81sdzlXDzC9XGj6EQwtWwh/iY2Af911Sp/jtx9o",
        &[
            "77.91.85.147:443"
        ],
    ),
    // Nickname: CarabineroDeChile
    fallback(
        "58698C5E518D428DCA4D9780AD8379BB63B57B42",
        "4irJTRkkklBP/O8jI0zV9qgcCvRiUC9Wdz3bIL7yTzo",
        &[
            "107.189.8.65:443",
            "[2605:6400:30:f623:5a78:29a6:8492:27b0]:443"
        ],
    ),
    // Nickname: prsv
    fallback(
        "302FEB0025AD49D2536B322C0A4C5F32F8322518",
        "yfitJW/BnNu356LmUT7/2r0Zqkq2tII7I6cq7BoYlAE",
        &[
            "103.252.88.80:9400"
        ],
    ),
    // Nickname: ThePlagueWorld
    fallback(
        "85D141F0B127C9517A8C88B15D21F622954AA6AF",
        "L558rF/2mhAvmqpv7wYhoG7jgyPxA6H0NylIFZ8o7g8",
        &[
            "185.196.220.82:9001"
        ],
    ),
    // Nickname: chinachinachina
    fallback(
        "09F9CD95B472256DFDFF666A0CFD82A3F3CE3514",
        "9C0EAF6+h7nLroq25kMPZakdJ+7OIaynyFVCTKXdG84",
        &[
            "51.89.106.29:9001"
        ],
    ),
    // Nickname: prometheus
    fallback(
        "66BFE89DDFEAA70B275C985CB569248471C6F0C5",
        "uAbEHuyWmw95WVHQH0JgiJcNimB3fW7lUk095Pu+CPI",
        &[
            "71.197.138.217:443"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "3F6E66FDA54B0CED35F01A16AF5D034DDDD8D48C",
        "Som67Zf0zSjySuoLjxMjW0EjKY0b7lyRaTa8cjjTy5E",
        &[
            "45.138.16.222:9000",
            "[2a12:a800:2:1:45:138:16:222]:9000"
        ],
    ),
    // Nickname: prsv
    fallback(
        "C0C508A0959FB1C9B5CAA7A152FE55388D335144",
        "FQN439EfaDWv4ceNd/5NeRYtlxruK6rExmKjsNK8o1g",
        &[
            "103.252.90.78:9000"
        ],
    ),
    // Nickname: F3Netze
    fallback(
        "9971F51A3274758B5C59E1D6580ED2C13E13CBEC",
        "cggwXqDgzCUQesXEApe+afP4rY5p1RJBS4qTC11LMdo",
        &[
            "185.220.100.254:9100",
            "[2a0b:f4c0:16c:2::1]:9100"
        ],
    ),
    // Nickname: relayonbephomet
    fallback(
        "C0E7334A181184ABD07698D04ADC19E15E3EE184",
        "vlhMRPsRDfKvCkRL8QIlYLiXZ8N9bhkbmEYhdXq15D0",
        &[
            "185.220.100.244:9000",
            "[2a0b:f4c0:16c:12::1]:9000"
        ],
    ),
    // Nickname: TorRelay1c
    fallback(
        "255CC3EA8DB03A9E45EAA7D2CE8A05A4F26F0457",
        "LCZIbadeZQE1uJOjHj3HJ8MlKgXNEp788ocmpXW6Uls",
        &[
            "89.58.54.129:853",
            "[2a03:4000:69:e40::1]:853"
        ],
    ),
    // Nickname: node1
    fallback(
        "ED012032F2B4622DB1847EFD2BC5F22AB5BEC454",
        "5pdmD3cCz6V6AU+pu8mpr/FZYd1yhgfVlwZ+oxVwa7E",
        &[
            "194.62.248.21:9001",
            "[2a0e:97c0:3ea:372::1]:9001"
        ],
    ),
    // Nickname: Megalon
    fallback(
        "08C1572C09F270010A277E58CDFBE270CBE2331B",
        "RFiT2ZKlB1BjC55w7o1fxMMFgCkg/14YsluDbF5xi1w",
        &[
            "84.19.176.161:443"
        ],
    ),
    // Nickname: SleepSnowflake1732
    fallback(
        "13794F4C8E443AA47D46DDF9F9B83659290C9AAF",
        "LM5cxxkTom/g0pMwEC7VuqCGXRLSCeQxjpZ0nxAHcD0",
        &[
            "141.145.210.16:443",
            "[2603:c027:c001:b4ff:b6cd:ec14:b49c:307b]:443"
        ],
    ),
    // Nickname: ChristopheRelay
    fallback(
        "50BAD4E48646797796107ECF0192178495247202",
        "bxZI8bS/jD9ecau1JuF4gX9qCgxfR2cRcJyOvL1zK1I",
        &[
            "23.233.0.213:9001"
        ],
    ),
    // Nickname: archofnoah
    fallback(
        "82BEDF4CCF56BF65F75F64A478B10853A994A9D5",
        "dltFe8g2BYhW7KVv8qxM+n2HK/rFKhzxFSb20HOJH5U",
        &[
            "5.255.118.244:9001"
        ],
    ),
    // Nickname: RDPdotSH
    fallback(
        "775D0AA34AC2E892CB98596F706DB96E6D49DD7A",
        "KEQxg3KUJ1SdfdTQmTr3QlW43yCI0F7/kpZLbGI5v1Q",
        &[
            "45.94.31.26:443"
        ],
    ),
    // Nickname: Doedelkiste08
    fallback(
        "E388F7BD196F5195AEF114552585152EA6942329",
        "c/0cevi2Tq6EVSknwZ6treFfSO2vhSQTiFpKMY1JaIo",
        &[
            "91.143.81.27:443",
            "[2a02:180:6:1::2fce]:443"
        ],
    ),
    // Nickname: fuchs4
    fallback(
        "1F266797A941DF885B96C2862F2A007FD32B66D9",
        "Epv7/Fvx7bESvNBeeQ1qRMowvkVOIB1M30dSQ62GmAg",
        &[
            "65.21.94.13:9443",
            "[2a01:4f9:3b:468e::13]:9443"
        ],
    ),
    // Nickname: Quetzalcoatl
    fallback(
        "A9044B9AE03BCA32DEECB70A973E34C02F72CFC8",
        "OOR1OLEwwBB/r1e1dvp++Iy19P9UwdUnp4w0msCkWVI",
        &[
            "107.189.5.7:9000",
            "[2605:6400:30:f534:ae1d:c3d9:9941:d85e]:9000"
        ],
    ),
    // Nickname: PoohBear18645
    fallback(
        "8F892BBC4715AA201CECC8FE6316AFF5AD40C1F2",
        "WTr33lReRec4o+YNsZIF5HM5SQnzCm/qd1p0zarrnvU",
        &[
            "205.185.117.232:15698",
            "[2605:6400:20:19cb:dd92:af73:5b09:3e0a]:15698"
        ],
    ),
    // Nickname: TorRules
    fallback(
        "22FCB2EDBE4BCF62E8646B276B895DFF206891F2",
        "eDjqXuMcONQu7FB246B+ooRllrPsFdOMPQStp7BP060",
        &[
            "87.221.15.164:25001"
        ],
    ),
]
