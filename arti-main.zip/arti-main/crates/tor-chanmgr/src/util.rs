//! Utilities used for the channel manager.

pub(crate) mod defer;
