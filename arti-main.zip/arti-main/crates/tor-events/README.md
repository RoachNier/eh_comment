# tor-events

Tools for generating a stream of structured events, similar to C tor's `ControlPort`.

License: MIT OR Apache-2.0
