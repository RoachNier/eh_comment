# arti-rpcserver

Backend for Arti's RPC service

License: MIT OR Apache-2.0
