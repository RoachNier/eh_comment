# arti-config

Removed crate.  (Tools for configuration management in Arti)

This crate was part of
[Arti](https://gitlab.torproject.org/tpo/core/arti/), a project to
implement [Tor](https://www.torproject.org/) in Rust.

The project continues, but this particular crate is now superseded.
This empty crate is published as a tombstone.

License: MIT OR Apache-2.0
