# tor-config-path

Low-level file path handling for configuration of the Arti Tor implementation.

## Overview

This crate is part of
[Arti](https://gitlab.torproject.org/tpo/core/arti/), a project to
implement [Tor](https://www.torproject.org/) in Rust.

---
License: MIT OR Apache-2.0
